#include <stdio.h>

int main(int argc, char *argv[])
{
  printf("Hello OS3!\n");
  return 2017;
  /* What is the actual exit status? Why? */
}
